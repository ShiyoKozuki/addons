#! /bin/bash
cd "C:/Ashita 4/addons/mobdb"
git add .
git commit -m "generic"
git push origin main