--Zone: Everbloom Hollow
--Zone ID: 86
return {
    [47] = { Name='King Arthro', Notorious=true, Aggro=true, Link=false, TrueSight=false, Job=0, MinLevel=95, MaxLevel=95, Immunities=20, Respawn=0, Sight=false, Sound=true, Blood=false, Magic=false, JA=false, Scent=false, Drops={836,11286,16178,12924,13189}, Spells={105,202,226,240}, Modifiers={Slashing=1, Piercing=1, H2H=1, Impact=1, Fire=1.3, Ice=1.3, Wind=1.3, Earth=1.3, Lightning=1.5, Water=0.7, Light=1.3, Dark=1.3} },
    [48] = { Name='Knight Crab', Notorious=false, Aggro=true, Link=true, TrueSight=false, Job=0, MinLevel=76, MaxLevel=76, Immunities=0, Respawn=0, Sight=false, Sound=true, Blood=false, Magic=false, JA=false, Scent=false, Drops={}, Spells={}, Modifiers={Slashing=1, Piercing=1, H2H=1, Impact=1, Fire=1.3, Ice=1.3, Wind=1.3, Earth=1.3, Lightning=1.5, Water=0.7, Light=1.3, Dark=1.3} },
};