--Zone: Ruhotz Silvermines
--Zone ID: 93
return {
    [256] = { Name='Guivre', Notorious=true, Aggro=true, Link=false, TrueSight=false, Job=0, MinLevel=95, MaxLevel=95, Immunities=1, Respawn=0, Sight=true, Sound=true, Blood=false, Magic=false, JA=false, Scent=false, Drops={909,11288,19212}, Spells={}, Modifiers={Slashing=1, Piercing=1, H2H=1, Impact=1, Fire=0.5, Ice=0.9, Wind=1, Earth=1, Lightning=1.3, Water=1.3, Light=1.3, Dark=1.5} },
    [257] = { Name='Lambton Worm', Notorious=false, Aggro=true, Link=false, TrueSight=false, Job=0, MinLevel=95, MaxLevel=95, Immunities=0, Respawn=0, Sight=false, Sound=true, Blood=false, Magic=false, JA=false, Scent=false, Drops={901,909,836,11285,16275,16344,17751}, Spells={}, Modifiers={Slashing=1, Piercing=1, H2H=1, Impact=1, Fire=0.5, Ice=0.5, Wind=0.85, Earth=0.05, Lightning=0.5, Water=0.5, Light=0.5, Dark=0.5} },
};