#! /bin/bash
cd "C:/Ashita 4/addons/modb"
git reset --hard HEAD
git clean -fxd
git pull